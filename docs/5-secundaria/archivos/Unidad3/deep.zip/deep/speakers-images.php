<?php
/**
 * Deep Theme.
 *
 * The template for displaying speakers image
 *
 * @since   1.0.0
 * @author  Webnus
 */

if ( defined( 'DEEPCORE' ) ) {
	do_action( 'deepcore_speakers_images' );
}