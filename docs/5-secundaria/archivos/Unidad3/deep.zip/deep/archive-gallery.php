<?php
/**
 * Deep Theme.
 *
 * The template for gallery
 *
 * @since   1.0.0
 * @author  Webnus
 */

if ( defined( 'DEEPCORE' ) ) {
	WN_Archive_Gallery::get_instance();
}