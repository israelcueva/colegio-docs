<?php
/**
 * Deep Theme.
 *
 * The template for rooms
 *
 * @since   1.0.0
 * @author  Webnus
 */

if ( defined( 'DEEPCORE' ) ) {
	WN_Rooms_Archive::get_instance();
}