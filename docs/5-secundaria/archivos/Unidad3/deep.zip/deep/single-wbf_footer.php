<?php
/**
 * Deep Theme.
 *
 * The template for displaying footer
 *
 * @since   1.0.0
 * @author  Webnus
 */

if ( defined( 'DEEPCORE' ) ) {
	WN_Page::get_instance();
}