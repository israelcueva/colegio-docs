<?php
/**
 * Deep Theme.
 *
 * The template for displaying cause category
 *
 * @since   1.0.0
 * @author  Webnus
 */

if ( defined( 'DEEPCORE' ) ) {
	get_header();
	do_action( 'deepcore_taxonomy_cause_category' );
	get_footer();
}